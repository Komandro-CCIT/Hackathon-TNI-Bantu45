<section>
    <div class="container">

        <div class="col-md-12">
            <div class="heading text-center">
  <h1>About</h1>
            </div>
            <p class="lead">
              Website ini mengarah kepada bidang dukungan dalam supply persenjataan tni,
               dan prajurit tni yang akan berlatih. Aplikasi kami juga memberikan informasi
                tentang dimana tempat yang akan digunakan untuk berlatih, dan mendukung
                 suply makanan, obat obatan yang di perlukan yang akan di kirim. Website
                  ini juga bisa digunakan untuk memberikan sumbangan terhadap korban bencana
                  alam, karena tni biasanya sering menyelenggarakan amal bantuan
              terhadap bencana alam, berupa tenaga atau makanan, pakaian, dan obat obatan.
            </p>
      </div>
</div>
</section>
